<?php

//Isi USER-AGENT Sesuai Data Kalian
$user = "Mozilla/5.0 (Linux; Android 10; RMX2151) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.74 Mobile Safari/537.36";

//Isi Cookie Sesuai Data Kalian
$cookie = "__ddg1=kT1nBxBDsun52qeRGPnq;_ga=GA1.2.809118195.1638031091;_gid=GA1.2.1417491718.1638031091;PHPSESSID=uo3p8hl2bqrvpm1hplvkiv08v1";
